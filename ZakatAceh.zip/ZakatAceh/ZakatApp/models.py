from django.db import models

class Operator(models.Model) :
    operator_id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=500)
    password = models.CharField(max_length=500)

class Pemberi(models.Model) :
    pemberi_id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=500)
    email = models.EmailField(max_length=254)
    password = models.CharField(max_length=500)
    nama = models.CharField(max_length=500)
    nomor_hp = models.CharField(max_length=500)
    nomor_kk = models.CharField(max_length=500)
    alamat = models.CharField(max_length=500)
    jumlah_anggota_keluarga = models.IntegerField()
    foto = models.CharField(max_length=500)
    
class Penerima(models.Model) :
    penerima_id = models.AutoField(primary_key=True)
    nama = models.CharField(max_length=500)
    email = models.EmailField(max_length=254)
    nomor_hp = models.CharField(max_length=500)
    nomor_kk = models.CharField(max_length=500)
    alamat = models.CharField(max_length=500)

class Jadwal(models.Model) :
    jadwal_id = models.AutoField(primary_key=True)
    tanggal_mulai = models.DateField()
    tanggal_berakhir = models.DateField()
    harga_beras = models.IntegerField()
    status = models.BooleanField(default=False)
    
class Pembayaran(models.Model) :
    pembayaran_id = models.AutoField(primary_key=True)
    pemberi_id = models.ForeignKey(Pemberi, on_delete=models.CASCADE)
    jadwal_id = models.ForeignKey(Jadwal, on_delete=models.DO_NOTHING)
    tanggal = models.DateField()
    nominal = models.IntegerField()
    status = models.CharField(max_length=500)
