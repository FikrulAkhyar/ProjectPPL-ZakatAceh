from rest_framework import serializers
from ZakatApp.models import Operator, Pemberi, Penerima, Jadwal, Pembayaran

class OperatorSerializers(serializers.ModelSerializer) :
    class Meta :
        model = Operator
        fields = ('operator_id', 'username', 'password')

class PemberiSerializers(serializers.ModelSerializer) :
    class Meta :
        model = Pemberi
        fields = ('pemberi_id', 'username', 'email', 'password', 'nama', 'nomor_hp', 'nomor_kk', 'alamat', 'jumlah_anggota_keluarga', 'foto')
        
class PenerimaSerializers(serializers.ModelSerializer) :
    class Meta :
        model = Penerima
        fields = ('penerima_id', 'nama', 'email', 'nomor_hp', 'nomor_kk', 'alamat')

class JadwalSerializers(serializers.ModelSerializer) :
    class Meta :
        model = Jadwal
        fields = ('jadwal_id', 'tanggal_mulai', 'tanggal_berakhir', 'harga_beras', 'status')

class PembayaranSerializers(serializers.ModelSerializer) :
    class Meta :
        model = Pembayaran
        fields = ('pembayaran_id', 'pemberi_id', 'jadwal_id', 'tanggal', 'nominal', 'status')