from rest_framework import serializers
from ZakatApp.models import Operator, Pemberi, Penerima, Konten, Pembayaran

class OperatorSerializers(serializers.ModelSerializer) :
    class Meta :
        model = Operator
        fields = ('operator_id', 'username', 'password')

class PemberiSerializers(serializers.ModelSerializer) :
    class Meta :
        model = Pemberi
        fields = ('pemberi_id', 'username', 'email', 'password', 'nama', 'nomor_hp', 'nomor_kk', 'alamat', 'jumlah_anggota_keluarga', 'foto')
        
class PenerimaSerializers(serializers.ModelSerializer) :
    class Meta :
        model = Penerima
        fields = ('penerima_id', 'nama', 'email', 'nomor_hp', 'nomor_kk', 'alamat')

class KontenSerializers(serializers.ModelSerializer) :
    class Meta :
        model = Konten
        fields = ('konten_id', 'tanggal_mulai', 'tanggal_berakhir', 'harga_beras')

class PembayaranSerializers(serializers.ModelSerializer) :
    class Meta :
        model = Pembayaran
        fields = ('pembayaran_id', 'pemberi_id', 'tanggal', 'nominal', 'status')