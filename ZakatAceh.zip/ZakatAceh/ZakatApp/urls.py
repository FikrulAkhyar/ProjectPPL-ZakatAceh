from django.urls import re_path
from ZakatApp import views

from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    re_path(r'^operator$', views.operatorApi),
    re_path(r'^operator/([0-9]+)$', views.operatorApi),
    
    re_path(r'^pemberi$', views.pemberiApi),
    re_path(r'^pemberi/([0-9]+)$', views.pemberiApi),
    
    re_path(r'^penerima$', views.penerimaApi),
    re_path(r'^penerima/([0-9]+)$', views.penerimaApi),
    
    re_path(r'^konten$', views.kontenApi),
    re_path(r'^konten/([0-9]+)$', views.kontenApi),
    
    re_path(r'^pembayaran$', views.pembayaranApi),
    re_path(r'^pembayaran/([0-9]+)$', views.pembayaranApi),
    
    re_path(r'^pemberi/savefile', views.saveFile)
]+static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
