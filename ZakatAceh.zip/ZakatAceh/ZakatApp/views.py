from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from django.http.response import JsonResponse

from ZakatApp.models import Operator, Pemberi, Penerima, Jadwal, Pembayaran
from ZakatApp.serializers import OperatorSerializers, PemberiSerializers, PenerimaSerializers, JadwalSerializers, PembayaranSerializers

from django.core.files.storage import default_storage

@csrf_exempt
def operatorApi(request, id=0) :
    if request.method == 'GET' :
        operators = Operator.objects.all()
        operators_serializer = OperatorSerializers(operators, many = True)
        return JsonResponse(operators_serializer.data, safe = False)
    elif request.method == 'POST' :
        operator_data = JSONParser().parse(request)
        operators_serializer = OperatorSerializers(data = operator_data)
        if operators_serializer.is_valid() :
            operators_serializer.save()
            return JsonResponse("Data berhasil ditambahkan!", safe = False)
        return JsonResponse("Gagal menambahkan data!", safe = False)
    elif request.method == 'PUT' :
        operator_data = JSONParser().parse(request)
        operator = Operator.objects.get(operator_id = operator_data['operator_id'])
        operator_serializer = OperatorSerializers(operator, data = operator_data)
        if operator_serializer.is_valid() :
            operator_serializer.save()
            return JsonResponse("Berhasil memperbarui data!", safe = False)
        return JsonResponse("Gagal memperbarui data!", safe = False)
    elif request.method == 'DELETE' :
        operator = Operator.objects.get(operator_id = id)
        operator.delete()
        return JsonResponse("Berhasil menghapus data!", safe = False)
    return JsonResponse("Gagal menghapus data!", safe = False)



@csrf_exempt
def pemberiApi(request, id=0) :
    if request.method == 'GET' :
        pemberis = Pemberi.objects.all()
        pemberis_serializer = PemberiSerializers(pemberis, many = True)
        return JsonResponse(pemberis_serializer.data, safe = False)
    elif request.method == 'POST' :
        pemberi_data = JSONParser().parse(request)
        pemberis_serializer = PemberiSerializers(data = pemberi_data)
        if pemberis_serializer.is_valid() :
            pemberis_serializer.save()
            return JsonResponse("Data berhasil ditambahkan!", safe = False)
        return JsonResponse("Gagal menambahkan data!", safe = False)
    elif request.method == 'PUT' :
        pemberi_data = JSONParser().parse(request)
        pemberi = Pemberi.objects.get(pemberi_id = pemberi_data['pemberi_id'])
        pemberi_serializer = PemberiSerializers(pemberi, data = pemberi_data)
        if pemberi_serializer.is_valid() :
            pemberi_serializer.save()
            return JsonResponse("Berhasil memperbarui data!", safe = False)
        return JsonResponse("Gagal memperbarui data!", safe = False)
    elif request.method == 'DELETE' :
        pemberi = Pemberi.objects.get(pemberi_id = id)
        pemberi.delete()
        return JsonResponse("Berhasil menghapus data!", safe = False)
    return JsonResponse("Gagal menghapus data!", safe = False)



@csrf_exempt
def penerimaApi(request, id=0) :
    if request.method == 'GET' :
        penerimas = Penerima.objects.all()
        penerimas_serializer = PenerimaSerializers(penerimas, many = True)
        return JsonResponse(penerimas_serializer.data, safe = False)
    elif request.method == 'POST' :
        penerima_data = JSONParser().parse(request)
        penerimas_serializer = PenerimaSerializers(data = penerima_data)
        if penerimas_serializer.is_valid() :
            penerimas_serializer.save()
            return JsonResponse("Data berhasil ditambahkan!", safe = False)
        return JsonResponse("Gagal menambahkan data!", safe = False)
    elif request.method == 'PUT' :
        penerima_data = JSONParser().parse(request)
        penerima = Penerima.objects.get(penerima_id = penerima_data['penerima_id'])
        penerima_serializer = PenerimaSerializers(penerima, data = penerima_data)
        if penerima_serializer.is_valid() :
            penerima_serializer.save()
            return JsonResponse("Berhasil memperbarui data!", safe = False)
        return JsonResponse("Gagal memperbarui data!", safe = False)
    elif request.method == 'DELETE' :
        penerima = Penerima.objects.get(penerima_id = id)
        penerima.delete()
        return JsonResponse("Berhasil menghapus data!", safe = False)
    return JsonResponse("Gagal menghapus data!", safe = False)




@csrf_exempt
def jadwalApi(request, id=0) :
    if request.method == 'GET' :
        jadwals = Jadwal.objects.all()
        jadwals_serializer = JadwalSerializers(jadwals, many = True)
        return JsonResponse(jadwals_serializer.data, safe = False)
    elif request.method == 'POST' :
        jadwal_data = JSONParser().parse(request)
        jadwals_serializer = JadwalSerializers(data = jadwal_data)
        if jadwals_serializer.is_valid() :
            jadwals_serializer.save()
            return JsonResponse("Data berhasil ditambahkan!", safe = False)
        return JsonResponse("Gagal menambahkan data!", safe = False)
    elif request.method == 'PUT' :
        jadwal_data = JSONParser().parse(request)
        jadwal = Jadwal.objects.get(jadwal_id = jadwal_data['jadwal_id'])
        jadwal_serializer = JadwalSerializers(jadwal, data = jadwal_data)
        if jadwal_serializer.is_valid() :
            jadwal_serializer.save()
            return JsonResponse("Berhasil memperbarui data!", safe = False)
        return JsonResponse("Gagal memperbarui data!", safe = False)
    elif request.method == 'DELETE' :
        jadwal = Jadwal.objects.get(jadwal_id = id)
        jadwal.delete()
        return JsonResponse("Berhasil menghapus data!", safe = False)
    return JsonResponse("Gagal menghapus data!", safe = False)



@csrf_exempt
def pembayaranApi(request, id=0) :
    if request.method == 'GET' :
        pembayarans = Pembayaran.objects.all()
        pembayarans_serializer = PembayaranSerializers(pembayarans, many = True)
        return JsonResponse(pembayarans_serializer.data, safe = False)
    elif request.method == 'POST' :
        pembayaran_data = JSONParser().parse(request)
        pembayarans_serializer = PembayaranSerializers(data = pembayaran_data)
        if pembayarans_serializer.is_valid() :
            pembayarans_serializer.save()
            return JsonResponse("Data berhasil ditambahkan!", safe = False)
        return JsonResponse("Gagal menambahkan data!", safe = False)
    elif request.method == 'PUT' :
        pembayaran_data = JSONParser().parse(request)
        pembayaran = Pembayaran.objects.get(pembayaran_id = pembayaran_data['pembayaran_id'])
        pembayaran_serializer = PembayaranSerializers(pembayaran, data = pembayaran_data)
        if pembayaran_serializer.is_valid() :
            pembayaran_serializer.save()
            return JsonResponse("Berhasil memperbarui data!", safe = False)
        return JsonResponse("Gagal memperbarui data!", safe = False)
    elif request.method == 'DELETE' :
        pembayaran = Pembayaran.objects.get(pembayaran_id = id)
        pembayaran.delete()
        return JsonResponse("Berhasil menghapus data!", safe = False)
    return JsonResponse("Gagal menghapus data!", safe = False)


@csrf_exempt
def saveFile(request) :
    file = request.FILES['file']
    file_name = default_storage.save(file.name, file)
    return JsonResponse(file_name, safe = False)
